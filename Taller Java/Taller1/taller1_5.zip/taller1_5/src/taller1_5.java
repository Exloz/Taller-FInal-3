import java.util.Scanner;

public class taller1_5 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("¿Cual es el nombre de la mascota? ");
        String nombreMascota = sc.next();

        System.out.println("¿Cual es la edad de la mascota?");
        int edadMascota = sc.nextInt();

        System.out.println("¿Cual es el tipo de la mascota?");
        String tipoMascota = sc.next();

        System.out.println("¿Cual es el nombre del dueño(a)?");
        String nombreDueño = sc.next();

        sc.close();

        System.out.println(nombreMascota + " es un(a) " + tipoMascota +
                " el cual, tiene " + edadMascota + " años de edad y " +
                nombreDueño + " es actualmente su dueño(a).");

    }

}
