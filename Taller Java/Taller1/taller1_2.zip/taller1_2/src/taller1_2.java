import java.util.Scanner;

public class taller1_2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("¿Cual es su nombre?: ");
        String nombre = sc.next();

        System.out.println("¿Cual es su apellido?: ");
        String apellido = sc.next();

        System.out.println("¿Cual es su edad?: ");
        int edad = sc.nextInt();

        System.out.println("¿Cual es su altura?: ");
        double altura = sc.nextDouble();

        sc.close();

    }

}