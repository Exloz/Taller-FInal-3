import java.util.Scanner;

public class taller1_3 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("¿Cual es su nombre?: ");
        String nombre = sc.next();

        System.out.println("¿Cual es su apellido?: ");
        String apellido = sc.next();

        System.out.println("¿Cual es el nombre de su madre?: ");
        String nombreMadre = sc.next();

        System.out.println("¿Cual es el apellido de su madre?: ");
        String apellidoMadre = sc.next();

        System.out.println("¿Cual es el nombre de su padre?: ");
        String nombrePadre = sc.next();

        System.out.println("¿Cual es el apellido de su padre?: ");
        String apellidoPadre = sc.next();

        sc.close();

        System.out.println("Yo " + nombre + " " + apellido +
                ", soy hijo de " + nombreMadre + " y " +
                nombrePadre + ".");

    }

}