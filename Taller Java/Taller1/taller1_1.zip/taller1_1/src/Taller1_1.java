import java.util.Scanner;

public class Taller1_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("¿Cual es tu nombre?: ");
        String nombre = sc.next();

        System.out.println("¿cual es tu apellido?: ");
        String apellido = sc.next();

        sc.close();

    }

}