import java.util.Scanner;

public class taller1_4 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el país: ");
        String nombrePais = scanner.next();

        System.out.println("Ingrese la ciudad capital: ");
        String nombreCiudad = scanner.next();

        scanner.close();

        System.out.println("La ciudad " + nombreCiudad +
                ", es la capital del país " + nombrePais + ".");

    }

}
