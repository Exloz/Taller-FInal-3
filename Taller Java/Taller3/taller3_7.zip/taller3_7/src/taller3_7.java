import java.util.Scanner;
public class taller3_7 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int control;
        int i;
        int retiro;
        String marca1,marca2,marca3,marca4,marca5;
        String nombre1,nombre2,nombre3,nombre4,nombre5;
        String placa,placa1,placa2,placa3,placa4,placa5;
        int telefono1, telefono2, telefono3, telefono4, telefono5;
        placa1 = " ";
        placa2 = " ";
        placa3 = " ";
        placa4 = " ";
        placa5 = " ";
        marca1 = " ";
        marca2 = " ";
        marca3 = " ";
        marca4 = " ";
        marca5 = " ";
        nombre1 = " ";
        nombre2 = " ";
        nombre3 = " ";
        nombre4 = " ";
        nombre5 = " ";
        telefono1 = 0;
        telefono2 = 0;
        telefono3 = 0;
        telefono4 = 0;
        telefono5 = 0;

        i = 0;

        do {
            System.out.println("****PARQUEADERO EL GUARDIAN****");
            System.out.println("Opciones");
            System.out.println("1. Ingreso de vehiculo al parqueadero");
            System.out.println("2. Retiro de vehiculo del parqueadero");
            System.out.println("3. Consultar si el vehiculo se encuentra en el parqueadero");
            System.out.println("4. Salir");
            control = sc.nextInt();
            switch (control) {
                case 1:
                    if (i==5) {
                        System.out.println("El parqueadero se encuentra lleno");
                    } else {
                        if (placa1.equals(" ")) {
                            System.out.println("Ingrese la placa del vehiculo");
                            placa1 = sc.next();
                            System.out.println("Ingrese la marca del vehiculo");
                            marca1 = sc.next();
                            System.out.println("Ingrese el nombre completo del cliente");
                            nombre1 = sc.next();
                            System.out.println("Ingrese el telefono del cliente");
                            telefono1 = sc.nextInt();
                            i = +i;
                            System.out.println("Vehiculo ingresado con exito");
                        } else {
                            if (placa2.equals(" ")) {
                                System.out.println("Ingrese la placa del vehiculo");
                                placa2 = sc.next();
                                System.out.println("Ingrese la marca del vehiculo");
                                marca2 = sc.next();
                                System.out.println("Ingrese el nombre completo del cliente");
                                nombre2 = sc.next();
                                System.out.println("Ingrese el telefono del cliente");
                                telefono2 = sc.nextInt();
                                i = +i;
                                System.out.println("Vehiculo ingresado con exito");
                            } else {
                                if (placa3.equals(" ")) {
                                    System.out.println("Ingrese la placa del vehiculo");
                                    placa3 = sc.next();
                                    System.out.println("Ingrese la marca del vehiculo");
                                    marca3 = sc.next();
                                    System.out.println("Ingrese el nombre completo del cliente");
                                    nombre3 = sc.next();
                                    System.out.println("Ingrese el telefono del cliente");
                                    telefono3 = sc.nextInt();
                                    i = +i;
                                    System.out.println("Vehiculo ingresado con exito");
                                } else {
                                    if (placa4.equals(" ")) {
                                        System.out.println("Ingrese la placa del vehiculo");
                                        placa4 = sc.next();
                                        System.out.println("Ingrese la marca del vehiculo");
                                        marca4 = sc.next();
                                        System.out.println("Ingrese el nombre completo del cliente");
                                        nombre4 = sc.next();
                                        System.out.println("Ingrese el telefono del cliente");
                                        telefono4 = sc.nextInt();
                                        i = +i;
                                        System.out.println("Vehiculo ingresado con exito");
                                    } else {
                                        if (placa5.equals(" ")) {
                                            System.out.println("Ingrese la placa del vehiculo");
                                            placa5 = sc.next();
                                            System.out.println("Ingrese la marca del vehiculo");
                                            marca5 = sc.next();
                                            System.out.println("Ingrese el nombre completo del cliente");
                                            nombre5 = sc.next();
                                            System.out.println("Ingrese el telefono del cliente");
                                            telefono5 = sc.nextInt();
                                            i = +i;
                                            System.out.println("Vehiculo ingresado con exito");
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                case 2:
                    System.out.println("�Cual vehiculo desea retirar? Elija la plaza donde se encuentre (1 al 5)");
                    retiro = sc.nextInt();
                    switch (retiro) {
                        case 1:
                            placa1 = " ";
                            marca1 = " ";
                            nombre1 = " ";
                            telefono1 = 0;
                            i = -1;
                            System.out.println("Vehiculo retirado exitosamente");
                            break;
                        case 2:
                            placa2 = " ";
                            marca2 = " ";
                            nombre2 = " ";
                            telefono2 = 0;
                            i = -1;
                            System.out.println("Vehiculo retirado exitosamente");
                            break;
                        case 3:
                            placa3 = " ";
                            marca3 = " ";
                            nombre3 = " ";
                            telefono3 = 0;
                            i = -1;
                            System.out.println("Vehiculo retirado exitosamente");
                            break;
                        case 4:
                            placa4 = " ";
                            marca4 = " ";
                            nombre4 = " ";
                            telefono4 = 0;
                            i = -1;
                            System.out.println("Vehiculo retirado exitosamente");
                            break;
                        case 5:
                            placa5 = " ";
                            marca5 = " ";
                            nombre5 = " ";
                            telefono5 = 0;
                            i = -1;
                            System.out.println("Vehiculo retirado exitosamente");
                            break;
                    }
                    break;
                case 3:
                    System.out.println("Digite la placa del vehiculo");
                    placa = sc.next();
                    if (placa.equals(placa1)) {
                        System.out.println("Este vehiculo se encuentra en el parqueadero en la plaza 1");
                        System.out.println(placa1+", "+marca1+", "+nombre1+", "+telefono1+", ");
                    } else {
                        if (placa.equals(placa2)) {
                            System.out.println("Este vehiculo se encuentra en el parqueadero en la plaza 2");
                            System.out.println(placa2+", "+marca2+", "+nombre2+", "+telefono2+", ");
                        } else {
                            if (placa.equals(placa3)) {
                                System.out.println("Este vehiculo se encuentra en el parqueadero en la plaza 3");
                                System.out.println(placa3+", "+marca3+", "+nombre3+", "+telefono3+", ");
                            } else {
                                if (placa.equals(placa4)) {
                                    System.out.println("Este vehiculo se encuentra en el parqueadero en la plaza 4");
                                    System.out.println(placa4+", "+marca4+", "+nombre4+", "+telefono4+", ");
                                } else {
                                    if (placa.equals(placa5)) {
                                        System.out.println("Este vehiculo se encuentra en el parqueadero en la plaza 5");
                                        System.out.println(placa5+", "+marca5+", "+nombre5+", "+telefono5+", ");
                                    } else {
                                        System.out.println("Este vehiculo no se encuentra en el parqueadero");
                                    }
                                }
                            }
                        }
                    }
                    break;
                case 4:
                    System.out.println("Finalizando...");
                    System.out.println("**************************");
                    break;
            }
        } while (control!=4);
    }


}