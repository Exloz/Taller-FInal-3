import java.util.Scanner;
public class taller3_8 {

    public static boolean fnota(double nota) {
        boolean aprobado=false;
        if (nota>=6 && nota<=10) {
            aprobado = true;
        }
        return aprobado;
    }

    public static void aprobo(boolean aprobado) {
        if (aprobado==true) {
            System.out.println("CURSO APROBADO");
        } else {
            System.out.println("NO HA APROBADO EL CURSO");
        }
        System.out.println(" ");
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean aprobado1,aprobado2,aprobado3,aprobado4,aprobado5,aprobado6,aprobado7,aprobado8;
        int cc,cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8;
        int control;
        int edad1,edad2,edad3,edad4,edad5,edad6,edad7,edad8;
        int i;
        int nota,nota1,nota2,nota3,nota4,nota5,nota6,nota7,nota8;
        int telefono1,telefono2,telefono3,telefono4,telefono5,telefono6,telefono7,telefono8;
        String user1,user2,user3,user4,user5,user6,user7,user8;
        
        user1 = " ";
        user2 = " ";
        user3 = " ";
        user4 = " ";
        user5 = " ";
        user6 = " ";
        user7 = " ";
        user8 = " ";
        edad1 = 0;
        edad2 = 0;
        edad3 = 0;
        edad4 = 0;
        edad5 = 0;
        edad6 = 0;
        edad7 = 0;
        edad8 = 0;
        cc = 0;
        cc1 = 0;
        cc2 = 0;
        cc3 = 0;
        cc4 = 0;
        cc5 = 0;
        cc6 = 0;
        cc7 = 0;
        cc8 = 0;
        telefono1 = 0;
        telefono2 = 0;
        telefono3 = 0;
        telefono4 = 0;
        telefono5 = 0;
        telefono6 = 0;
        telefono7 = 0;
        telefono8 = 0;
        nota = 0;
        nota1 = 0;
        nota2 = 0;
        nota3 = 0;
        nota4 = 0;
        nota5 = 0;
        nota6 = 0;
        nota7 = 0;
        nota8 = 0;
        i = 0;
        do {
            System.out.println("****ESCUELA AUTOMOVILISTICA EL MAESTRO****");
            System.out.println("Opciones");
            System.out.println("1. Registro de ingreso al curso");
            System.out.println("2. Usuarios que cursaron y resultados");
            System.out.println("3. Ingreso de resultados");
            System.out.println("4. Salir");
            control = sc.nextInt();
            switch (control) {
                case 1:
                    if (i==8) {
                        System.out.println("Imposible de registrar, capacidad maxima alcanzada");
                    } else {
                        if (user1.equals(" ")) {
                            System.out.println("Ingrese el nombre completo del usuario");
                            user1 = sc.next();
                            System.out.println("Ingrese la edad del usuario");
                            edad1 = sc.nextInt();
                            System.out.println("Ingrese la cedula del usuario");
                            cc1 = sc.nextInt();
                            System.out.println("Ingrese el telefono del cliente");
                            telefono1 = sc.nextInt();
                            i = +i;
                            System.out.println("Usuario registrado satisfactoriamente");
                        } else {
                            if (user2.equals(" ")) {
                                System.out.println("Ingrese el nombre completo del usuario");
                                user2 = sc.next();
                                System.out.println("Ingrese la edad del usuario");
                                edad2 = sc.nextInt();
                                System.out.println("Ingrese la cedula del usuario");
                                cc2 = sc.nextInt();
                                System.out.println("Ingrese el telefono del cliente");
                                telefono2 = sc.nextInt();
                                i = +i;
                                System.out.println("Usuario registrado satisfactoriamente");
                            } else {
                                if (user3.equals(" ")) {
                                    System.out.println("Ingrese el nombre completo del usuario");
                                    user3 = sc.next();
                                    System.out.println("Ingrese la edad del usuario");
                                    edad3 = sc.nextInt();
                                    System.out.println("Ingrese la cedula del usuario");
                                    cc3 = sc.nextInt();
                                    System.out.println("Ingrese el telefono del cliente");
                                    telefono3 = sc.nextInt();
                                    i = +i;
                                    System.out.println("Usuario registrado satisfactoriamente");
                                } else {
                                    if (user4.equals(" ")) {
                                        System.out.println("Ingrese el nombre completo del usuario");
                                        user4 = sc.next();
                                        System.out.println("Ingrese la edad del usuario");
                                        edad4 = sc.nextInt();
                                        System.out.println("Ingrese la cedula del usuario");
                                        cc4 = sc.nextInt();
                                        System.out.println("Ingrese el telefono del cliente");
                                        telefono4 = sc.nextInt();
                                        i = +i;
                                        System.out.println("Usuario registrado satisfactoriamente");
                                    } else {
                                        if (user5.equals(" ")) {
                                            System.out.println("Ingrese el nombre completo del usuario");
                                            user5 = sc.next();
                                            System.out.println("Ingrese la edad del usuario");
                                            edad5 = sc.nextInt();
                                            System.out.println("Ingrese la cedula del usuario");
                                            cc5 = sc.nextInt();
                                            System.out.println("Ingrese el telefono del cliente");
                                            telefono5 = sc.nextInt();
                                            i = +i;
                                            System.out.println("Usuario registrado satisfactoriamente");
                                        } else {
                                            if (user6.equals(" ")) {
                                                System.out.println("Ingrese el nombre completo del usuario");
                                                user6 = sc.next();
                                                System.out.println("Ingrese la edad del usuario");
                                                edad6 = sc.nextInt();
                                                System.out.println("Ingrese la cedula del usuario");
                                                cc6 = sc.nextInt();
                                                System.out.println("Ingrese el telefono del cliente");
                                                telefono6 = sc.nextInt();
                                                i = +i;
                                                System.out.println("Usuario registrado satisfactoriamente");
                                            } else {
                                                if (user7.equals(" ")) {
                                                    System.out.println("Ingrese el nombre completo del usuario");
                                                    user7 = sc.next();
                                                    System.out.println("Ingrese la edad del usuario");
                                                    edad7 = sc.nextInt();
                                                    System.out.println("Ingrese la cedula del usuario");
                                                    cc7 = sc.nextInt();
                                                    System.out.println("Ingrese el telefono del cliente");
                                                    telefono7 = sc.nextInt();
                                                    i = +i;
                                                    System.out.println("Usuario registrado satisfactoriamente");
                                                } else {
                                                    if (user8.equals(" ")) {
                                                        System.out.println("Ingrese el nombre completo del usuario");
                                                        user8 = sc.next();
                                                        System.out.println("Ingrese la edad del usuario");
                                                        edad8 = sc.nextInt();
                                                        System.out.println("Ingrese la cedula del usuario");
                                                        cc8 = sc.nextInt();
                                                        System.out.println("Ingrese el telefono del cliente");
                                                        telefono8 = sc.nextInt();
                                                        i = +i;
                                                        System.out.println("Usuario registrado satisfactoriamente");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                case 2:
                    System.out.println("1.");
                    System.out.println("-Nombre: "+user1);
                    System.out.println("-Edad: "+edad1);
                    System.out.println("-C.C: "+cc1);
                    System.out.println("-Telefono: "+telefono1);
                    System.out.println("-Nota del curso: "+nota1);
                    aprobado1 = fnota(nota1);
                    aprobo(aprobado1);
                    System.out.println("2.");
                    System.out.println("-Nombre: "+user2);
                    System.out.println("-Edad: "+edad2);
                    System.out.println("-C.C: "+cc2);
                    System.out.println("-Telefono: "+telefono2);
                    System.out.println("-Nota del curso: "+nota2);
                    aprobado2 = fnota(nota2);
                    aprobo(aprobado2);
                    System.out.println("3.");
                    System.out.println("-Nombre: "+user3);
                    System.out.println("-Edad: "+edad3);
                    System.out.println("-C.C: "+cc3);
                    System.out.println("-Telefono: "+telefono3);
                    System.out.println("-Nota del curso: "+nota3);
                    aprobado3 = fnota(nota3);
                    aprobo(aprobado3);
                    System.out.println("4.");
                    System.out.println("-Nombre: "+user4);
                    System.out.println("-Edad: "+edad4);
                    System.out.println("-C.C: "+cc4);
                    System.out.println("-Telefono: "+telefono4);
                    System.out.println("-Nota del curso: "+nota4);
                    aprobado4 = fnota(nota4);
                    aprobo(aprobado4);
                    System.out.println("5.");
                    System.out.println("-Nombre: "+user5);
                    System.out.println("-Edad: "+edad5);
                    System.out.println("-C.C: "+cc5);
                    System.out.println("-Telefono: "+telefono5);
                    System.out.println("-Nota del curso: "+nota5);
                    aprobado5 = fnota(nota5);
                    aprobo(aprobado5);
                    System.out.println("6.");
                    System.out.println("-Nombre: "+user6);
                    System.out.println("-Edad: "+edad6);
                    System.out.println("-C.C: "+cc6);
                    System.out.println("-Telefono: "+telefono6);
                    System.out.println("-Nota del curso: "+nota6);
                    aprobado6 = fnota(nota6);
                    aprobo(aprobado6);
                    System.out.println("7.");
                    System.out.println("-Nombre: "+user7);
                    System.out.println("-Edad: "+edad7);
                    System.out.println("-C.C: "+cc7);
                    System.out.println("-Telefono: "+telefono7);
                    System.out.println("-Nota del curso: "+nota7);
                    aprobado7 = fnota(nota7);
                    aprobo(aprobado7);
                    System.out.println("8.");
                    System.out.println("-Nombre: "+user8);
                    System.out.println("-Edad: "+edad8);
                    System.out.println("-C.C: "+cc8);
                    System.out.println("-Telefono: "+telefono8);
                    System.out.println("-Nota del curso: "+nota8);
                    aprobado8 = fnota(nota8);
                    aprobo(aprobado8);
                    break;
                case 3:
                    System.out.println("Digite la cedula del usuario al cual desea agregar la nota");
                    cc = sc.nextInt();
                    if (cc==cc1) {
                        System.out.println("Digite la nota (1 a 10) para el usuario "+user1);
                        nota1 = sc.nextInt();
                        System.out.println("La nota ha sido guardada con exito");
                    } else {
                        if (cc==cc2) {
                            System.out.println("Digite la nota para el usuario "+user2);
                            nota2 = sc.nextInt();
                            System.out.println("La nota ha sido guardada con exito");
                        } else {
                            if (cc==cc3) {
                                System.out.println("Digite la nota para el usuario "+user3);
                                nota3 = sc.nextInt();
                                System.out.println("La nota ha sido guardada con exito");
                            } else {
                                if (cc==cc4) {
                                    System.out.println("Digite la nota para el usuario "+user4);
                                    nota4 = sc.nextInt();
                                    System.out.println("La nota ha sido guardada con exito");
                                } else {
                                    if (cc==cc5) {
                                        System.out.println("Digite la nota para el usuario "+user5);
                                        nota5 = sc.nextInt();
                                        System.out.println("La nota ha sido guardada con exito");
                                    } else {
                                        if (cc==cc6) {
                                            System.out.println("Digite la nota para el usuario "+user6);
                                            nota6 = sc.nextInt();
                                            System.out.println("La nota ha sido guardada con exito");
                                        } else {
                                            if (cc==cc7) {
                                                System.out.println("Digite la nota para el usuario "+user7);
                                                nota7 = sc.nextInt();
                                                System.out.println("La nota ha sido guardada con exito");
                                            } else {
                                                if (cc==cc8) {
                                                    System.out.println("Digite la nota para el usuario "+user8);
                                                    nota8 = sc.nextInt();
                                                    System.out.println("La nota ha sido guardada con exito");
                                                } else {
                                                    System.out.println("Este numero de cedula no corresponde a ningun usuario registrado.");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                case 4:
                    System.out.println("Finalizando...");
                    System.out.println("**************************");
                    break;
            }
        } while (control!=4);
    }
}