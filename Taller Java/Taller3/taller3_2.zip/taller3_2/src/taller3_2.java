public class taller3_2 {

    public static void main(String[] args) {
        int arbol;
        int espacio;
        int i;
        i = 1;

        while (i<=10) {
            arbol = 1;
            espacio = 10;
            while (espacio>=i) {
                System.out.print(" ");
                espacio = espacio-arbol;
            }
            while (arbol<=i) {
                System.out.print("*");
                arbol = arbol+1;
            }
            System.out.println("");
            i = i+1;
        }
    }
}