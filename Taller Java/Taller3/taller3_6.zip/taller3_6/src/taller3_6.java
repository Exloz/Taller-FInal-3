import java.util.Scanner;

public class taller3_6 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int contacto;
        int control;
        int eliminar;
        String nombre1,nombre2,nombre3,organizacion1,organizacion2,organizacion3;
        int telefono1,telefono2,telefono3;

        telefono1 = 0;
        telefono2 = 0;
        telefono3 = 0;
        nombre1 = " ";
        nombre2 = " ";
        nombre3 = " ";
        organizacion1 = " ";
        organizacion2 = " ";
        organizacion3 = " ";

        do {
            System.out.println("Opciones");
            System.out.println("1. Añadir contacto");
            System.out.println("2. Buscar contactos");
            System.out.println("3. Eliminar contactos");
            System.out.println("4. Salir");
            control = sc.nextInt();
            switch (control) {
                case 1:
                    System.out.println("Elija el contacto que desea añadir, 1, 2 o 3");
                    contacto = sc.nextInt();
                    switch (contacto) {
                        case 1:
                            System.out.println("Nombre:");
                            nombre1 = sc.next();
                            System.out.println("Telefono:");
                            telefono1 = sc.nextInt();
                            System.out.println("Organizacion:");
                            organizacion1 = sc.next();
                            if (telefono1==telefono1) {
                                System.out.println("Este numero ya estaba almacenado");
                                if (telefono1==telefono2) {
                                    System.out.println("Este numero ya estaba almacenado");
                                    if (telefono1==telefono3) {
                                        System.out.println("Este numero ya estaba almacenado");
                                    }
                                }
                            } else {
                                System.out.println("El contacto se ha almacenado con exito");
                            }
                            break;
                        case 2:
                            System.out.println("Nombre:");
                            nombre2 = sc.next();
                            System.out.println("Telefono:");
                            telefono2 = sc.nextInt();
                            System.out.println("Organizacion:");
                            organizacion2 = sc.next();
                            if (telefono2==telefono1) {
                                System.out.println("Este numero ya estaba almacenado");
                                if (telefono2==telefono2) {
                                    System.out.println("Este numero ya estaba almacenado");
                                    if (telefono3==telefono3) {
                                        System.out.println("Este numero ya estaba almacenado");
                                    }
                                }
                            } else {
                                System.out.println("El contacto se ha almacenado con exito");
                            }
                            break;
                        case 3:
                            System.out.println("Nombre:");
                            nombre3 = sc.next();
                            System.out.println("Telefono:");
                            telefono3 = sc.nextInt();
                            System.out.println("Organizacion:");
                            organizacion3 = sc.next();
                            if (telefono3==telefono1) {
                                System.out.println("Este numero ya estaba almacenado");
                                if (telefono3==telefono2) {
                                    System.out.println("Este numero ya estaba almacenado");
                                    if (telefono3==telefono3) {
                                        System.out.println("Este numero ya estaba almacenado");
                                    }
                                }
                            } else {
                                System.out.println("El contacto se ha almacenado con exito");
                            }
                            break;
                    }
                    break;
                case 2:
                    System.out.println("Contacto 1: "+nombre1+", "+telefono1+", "+organizacion1+".");
                    System.out.println("Contacto 2: "+nombre2+", "+telefono2+", "+organizacion2+".");
                    System.out.println("Contacto 3: "+nombre3+", "+telefono3+", "+organizacion3+".");
                    break;
                case 3:
                    System.out.println("Elija el contacto que desea eliminar, 1, 2 o 3");
                    eliminar = sc.nextInt();
                    switch (eliminar) {
                        case 1:
                            telefono1 = 0;
                            nombre1 = " ";
                            organizacion1 = " ";
                            System.out.println("Se ha eliminado el contacto 1 con exito");
                            break;
                        case 2:
                            telefono2 = 0;
                            nombre2 = " ";
                            organizacion2 = " ";
                            System.out.println("Se ha eliminado el contacto 2 con exito");
                            break;
                        case 3:
                            telefono3 = 0;
                            nombre3 = " ";
                            organizacion3 = " ";
                            System.out.println("Se ha eliminado el contacto 3 con exito");
                            break;
                    }
                    break;
                case 4:
                    System.out.println("Hasta luego, gracias por utilizar nuestra aplicacion");
                    System.out.println("**************************");
                    break;
            }
        } while (control!=4);

    }
}