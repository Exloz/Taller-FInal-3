public class taller3_1 {

    public static void main(String[] args) {
        int arbol;
        int control;

        for (control=1;control<=10;control++) {
            for (arbol=1;arbol<=control;arbol++) {
                System.out.print("*");
            }
            System.out.println("");
        }
    }


}