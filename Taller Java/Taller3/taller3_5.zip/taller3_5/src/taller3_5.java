import java.util.Scanner;

public class taller3_5 {
    public static void main(String[] args) {
        int control;
        String nombre;
        nombre = " ";
        Scanner sc=new Scanner(System.in);

        do {
            System.out.println("Menu de usuario:");
            System.out.println("1. Captura nombre");
            System.out.println("2. Saludar persona");
            System.out.println("3. Salir del sistema");
            control = sc.nextInt();

            switch (control) {
                case 1:
                    System.out.println("Por favor escriba su nombre");
                    nombre = sc.next();
                    break;
                case 2:
                    System.out.println("Buenos dias "+nombre+", bienvenido");
                    break;
                case 3:
                    System.out.println("Hasta luego");
                    break;
            }
        } while (control!=3);
    }
}