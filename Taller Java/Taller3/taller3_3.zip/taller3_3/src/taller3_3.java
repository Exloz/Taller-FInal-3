public class taller3_3 {

    public static void main(String[] args) {
        int arbol;
        int espacio;
        int i;
        i = 1;
        System.out.println("          *");
        do {
            arbol = 1;
            espacio = 10;
            do {
                System.out.print(" ");
                espacio = espacio-arbol;
            } while (espacio!=i);
            System.out.print("*");
            do {
                System.out.print("**");
                arbol = arbol+1;
            } while (arbol<=i);
            System.out.println("");
            i = i+1;
        } while (i!=10);
        System.out.println("         ***");
        System.out.println("         ***");
        System.out.println("        *****");
        System.out.println("       *******");
    }
}