import java.util.Scanner;

public class taller3_4 {

    public static void main(String[] args) {
        int i;
        int m;
        int n;
        Scanner sn = new Scanner(System.in);

        System.out.println("Escriba el numero del cual desea conocer su tabla de multiplicar");
        n =sn.nextInt();
        for (i=1;i<=10;i++) {
            m = i*n;
            System.out.println(i+" x "+n+" = "+m);
        }
    }
}