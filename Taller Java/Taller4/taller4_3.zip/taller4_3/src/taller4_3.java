import java.util.Scanner;
public class taller4_3 {

    public static void fprimo(boolean primo, int x) {
        if (primo==true) {
            System.out.println(x);
        }
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int i;
        boolean primo;
        int x;
        System.out.println("Numeros primos hasta el 1000");
        for (x=2;x<=999;x++) {
            i = 2;
            primo = true;
            while (primo==true && i<x) {
                if (x%i==0) {
                    primo = false;
                } else {
                    i = i+1;
                }
            }
            fprimo(primo,x);
        }
    }
}