import java.util.Scanner;
public class taller4_4 {

    public static void print(int matriz[][]) {
        int i;
        int j;
        int n;
        n = 01;
        for (i=0;i<=3;i++) {
            for (j=0;j<=4;j++) {
                matriz[i][j] = n;
                System.out.print(matriz[i][j]+" ");
                n = 1+n;
            }
            System.out.println(" ");
        }
        System.out.println("***************************");
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int i;
        int j;
        int matriz[][];
        int n;
        matriz = new int[4][5];
        print(matriz);
        for (i=0;i<=0;i++) {
            for (j=0;j<=4;j++) {
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println(" ");
        }
        for (i=1;i<=1;i++) {
            for (j=4;j>=0;j--) {
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println(" ");
        }
        for (i=2;i<=2;i++) {
            for (j=0;j<=4;j++) {
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println(" ");
        }
        for (i=3;i<=3;i++) {
            for (j=4;j>=0;j--) {
                System.out.print(matriz[i][j]+" ");
            }
            System.out.println(" ");
        }
    }
}