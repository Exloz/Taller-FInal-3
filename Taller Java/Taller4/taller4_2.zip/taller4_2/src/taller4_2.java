import java.util.Scanner;
public class taller4_2 {

    public static void par(int[][] matriz) {
        int columna;
        int fila;
        for (fila=0;fila<=1;fila++) {
            for (columna=0;columna<=9;columna++) {
                if (matriz[fila][columna]%2==0) {
                    System.out.print(matriz[fila][columna]+" ");
                }
            }
        }
    }

    public static void impar(int[][] matriz) {
        int columna;
        int fila;
        for (fila=0;fila<=1;fila++) {
            for (columna=0;columna<=9;columna++) {
                if (matriz[fila][columna]%2!=0) {
                    System.out.print(matriz[fila][columna]+" ");
                }
            }
        }
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int columna;
        int fila;
        int matriz[][];
        matriz = new int[2][10];
        System.out.println("Generando numeros aleatorios");
        for (fila=0;fila<=1;fila++) {
            for (columna=0;columna<=9;columna++) {
                matriz[fila][columna] = (int) (Math.floor(Math.random()*100)+1);
                System.out.print(matriz[fila][columna]+" ");
            }
        }
        System.out.println(" ");
        System.out.println("************************");
        System.out.print("Numeros pares: ");
        par(matriz);
        System.out.println(" ");
        System.out.println("************************");
        System.out.print("Numeros impares: ");
        impar(matriz);
        System.out.println(" ");
    }
}