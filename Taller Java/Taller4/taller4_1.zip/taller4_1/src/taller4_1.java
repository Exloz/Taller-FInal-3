import java.util.Scanner;
public class taller4_1 {

    public static void print(int[] vector) {
        int j;
        for (j=0;j<=4;j++) {
            System.out.println("["+j+"] = "+vector[j]);
        }
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int j;
        int numero;
        int vector[];
        vector = new int[5];
        j = 0;
        for (j=0;j<=4;j++) {
            System.out.println("Escriba el numero entero");
            numero = sc.nextInt();
            vector[j] = numero;
        }
        print(vector);
    }
}