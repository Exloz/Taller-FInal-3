import java.util.Scanner;
public class taller2_4 {
    public static void main(String[] args) {

        Scanner sn = new Scanner(System.in);

        String usuario;
        String peliculaSalida;
        String peliculaEntrada;
        boolean novedad;
        String descripcionNovedad;

        System.out.println("Nombre  del usuario: ");
        usuario= sn.next();

        System.out.println("Opciones\n" +
                "1. Alquilar pelicula.\n" +
                "2. Consultar las peliculas disponibles.\n" +
                "3. Recibir pelicula.\n" +
                "4. Salir.\n");

        int option = sn.nextInt();


        switch (option) {
            case 1: {
                System.out.println("¿Cual pelicula desea alquilar?: ");
                peliculaEntrada = sn.next();
                break;
            }
            case 2: {
                System.out.println("las peliculas disponibles son: ");
                System.out.println(
                        "-Dragon Ball: Super Hero\n" +
                        "-Top Gun: Maverick\n" +
                        "-Jurassic World: Dominion\n");
                break;
            }
            case 3: {
                System.out.println("¿Cual pelicula va a recibir? ");
                peliculaEntrada = sn.next();
                System.out.println("¿Alguna novedad sobre el estado de la pelicula entregada por "+ usuario + "? Escriba true o false.");
                novedad = Boolean.parseBoolean(sn.next());

                if (novedad==true){
                    System.out.println("Describa la novedad sobre la pelicula");
                    descripcionNovedad=sn.next();
                }else
                    System.out.println("La pelicula "+ peliculaEntrada + ". no presenta ninguna novedad" );
                break;
            }
            case 4: {
                System.out.println("Fin");
                break;
            }
            default:
                System.out.println("la opcion elegida es incorrecta." + option);
        }

        sn.close();

    }

}
