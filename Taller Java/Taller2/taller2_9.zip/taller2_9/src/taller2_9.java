import java.util.Scanner;
public class taller2_9 {
    public static void main(String[] args) {

        Scanner sn = new Scanner(System.in);

        double alturareg,alturatra,alturatri,areareg,areatra,areatri,basemayortra,basemenortra,basereg,basetri;
        int opcion;

        System.out.println("Calcular area de:");
        System.out.println("1. Rectangulo");
        System.out.println("2. Triangulo");
        System.out.println("3. Trapecio");
        opcion = sn.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("Ingrese la base del rectangulo");
                basereg = sn.nextDouble();

                System.out.println("Ingrese la altura del rectangulo");
                alturareg = sn.nextDouble();

                areareg = basereg*alturareg;
                System.out.println("El area del rectangulo es: "+areareg);

                break;
            case 2:
                System.out.println("Ingrese la base del triangulo");
                basetri = sn.nextDouble();

                System.out.println("Ingrese la altura del triangulo");
                alturatri = sn.nextDouble();

                areatri = (basetri*alturatri)/2;
                System.out.println("El area del triangulo es: "+areatri);

                break;
            case 3:
                System.out.println("Ingrese la base menor del trapecio");
                basemenortra = sn.nextDouble();

                System.out.println("Ingrese la base mayor del trapecio");
                basemayortra = sn.nextDouble();

                System.out.println("Ingrese la altura del trapecio");
                alturatra = sn.nextDouble();

                areatra = (basemenortra+basemayortra)*alturatra/2;
                System.out.println("El area del trapecio es: "+areatra);

                break;
            default:
                System.out.println("La opcion elegida es incorrecta");
        }

    }
}