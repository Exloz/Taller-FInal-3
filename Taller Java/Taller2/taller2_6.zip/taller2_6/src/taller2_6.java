import java.util.Scanner;

public class taller2_6 {
    public static void main(String[] args) {
        
        String cliente;
        String descripcionrepuesto;
        String motoin;
        String motoout;
        String novedad;
        String observacion;
        int opcion;
        boolean repuesto;

        Scanner sn = new Scanner(System.in);
        System.out.println("----Taller El Maquinista----");
        System.out.println("Ingrese el nombre del cliente:");
        cliente = sn.next();
        System.out.println("Opciones:");
        System.out.println("1. Ingreso de motocicleta");
        System.out.println("2. Salida de motocicleta");
        opcion = sn.nextInt();
        switch (opcion) {
            case 1:
                System.out.println("Marca y modelo de motocicleta que ingresa");
                motoin = sn.next();
                System.out.println("Observaciones del cliente:");
                observacion = sn.next();
                System.out.println("La motocicleta "+motoin+", de "+cliente+", presenta: "+observacion);
                break;
            case 2:
                System.out.println("Marca y modelo de motocicleta que sale");
                motoout = sn.next();
                System.out.println("Ingrese las novedades del servicio");
                novedad = sn.next();
                System.out.println("¿Se instalaron repuestos? Indique true o false");
                repuesto = sn.nextBoolean();
                if (repuesto==true) {
                    System.out.println("Describa los repuestos utilizados en la motocicleta "+motoout);
                    descripcionrepuesto = sn.next();
                    System.out.println("La motocicleta "+motoout+", de "+cliente+", se le realizo:");
                    System.out.println(novedad);
                    System.out.println("------------------------");
                    System.out.println("Y se cambiaron los siguientes repuestos:");
                    System.out.println(descripcionrepuesto);
                } else {
                    System.out.println("La motocicleta "+motoout+", de "+cliente+", se le realizo:");
                    System.out.println(novedad);
                    System.out.println("------------------------");
                    System.out.println("Y no se instalaron repuestos.");
                }
                break;
            default:
                System.out.println("La opcion elegida es incorrecta");
        }
    }


}

