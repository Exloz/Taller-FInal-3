import java.util.Scanner;

public class taller2_7 {
    public static void fimc(double imc, String nombre) {
        if (imc<18.5) {
            System.out.println(nombre+" tiene bajo peso");
        }
        if (imc>18.5 && imc<24.9) {
            System.out.println(nombre+" tiene peso normal");
        }
        if (imc>25 && imc<29.9) {
            System.out.println(nombre+" tiene sobrepeso");
        }
        if (imc>30) {
            System.out.println(nombre+" tiene obesidad");
        }
    }

    public static void main(String[] args){

        double estatura;
        double imc;
        String nombre;
        double peso;

        Scanner sn = new Scanner(System.in);
        System.out.println("Indique el nombre de la persona");
        nombre = sn.next();
        System.out.println("Indique el peso en kilogramos de la persona");
        peso = sn.nextDouble();
        System.out.println("Indique la estatura en metros de la persona");
        estatura = sn.nextDouble();

        imc = peso/(estatura*estatura);

        System.out.println(imc);

        fimc(imc,nombre);
    }


}