import java.util.Scanner;
public class taller2_8 {
    public static void main(String[] args) {

        Scanner sn = new Scanner(System.in);

        int contador;
        int contadorpedido;
        int cantidad;
        String decoracion;
        int opcion;
        String sabor;
        boolean venta;

        contadorpedido = 0;
        contador = 0;

        do {

            System.out.println("Opciones:");
            System.out.println("1. Registrar pedido");
            System.out.println("2. Consultar las tortas disponibles");
            System.out.println("3. Registrar venta");
            System.out.println("4. Salir");
            opcion = sn.nextInt();

            switch (opcion) {
                case 1:

                    System.out.println("sabor de la torta");
                    sabor = sn.next();

                    System.out.println("cantidad (porciones) de la torta");
                    cantidad = sn.nextInt();

                    System.out.println("decoracion de la torta");
                    decoracion = sn.next();

                    contadorpedido = contadorpedido + 1;

                    System.out.println("Hoy se han registrado " + contadorpedido + " pedido(s)");
                    break;
                case 2:

                    System.out.println("Las tortas disponibles son:");
                    System.out.println(" ");
                    System.out.println("Naranja, 12 porciones, superman");
                    System.out.println("fresa, 10 porciones, barbie");
                    System.out.println("chocolate, 6 porciones, among us");
                    System.out.println("Naranja, 14 porciones, sin decorar");
                    System.out.println("vino, 20 porciones, boda");
                    break;
                case 3:

                    System.out.println("¿Registrar venta? Escriba True o False");
                    venta = sn.nextBoolean();

                    if (venta == true) {
                        contador = contador + 1;
                        System.out.println("Hoy se han realizado " + contador + " venta(s)");
                    } else {
                        System.out.println("Hasta el momento se han realizado " + contador + " venta(s)");
                    }
                    break;
                case 4:
                    System.out.println("Hasta luego!");
                    break;
                default:
                    System.out.println("La opcion elegida es incorrecta");
            }
        } while (opcion != 4);

    }
}