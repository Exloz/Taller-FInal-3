import java.util.Scanner;
public class taller2_10 {

    public static double entrada(double saldo, double ingreso) {
        if (ingreso<0) {
            System.out.println("Ha ingresado un monto incorrecto");
        } else {
            System.out.println("Se han ingresado "+ingreso+" pesos con exito!");
            saldo = saldo+ingreso;
        }
        return saldo;
    }

    public static double salida(double saldo, double retiro) {
        if (retiro>saldo) {
            System.out.println("Ha ingresado un monto mayor al de su saldo total, no es posible realizar esta transaccion");
        } else {
            System.out.println("Se han retirado "+retiro+" pesos con exito!");
            saldo = saldo-retiro;
        }
        return saldo;
    }
    public static void main(String[] args) {

        Scanner sn = new Scanner(System.in);

        double ingreso,retiro,saldo;
        int opcion;

        saldo = 100000;

        do {
            System.out.println("Bienvenido a Su banco fiel, Esteban!");
            System.out.println("***************************************");
            System.out.println("¿Que desea realizar?");
            System.out.println("1. Realizar ingreso");
            System.out.println("2. Realizar retiro");
            System.out.println("3. Consultar saldo");
            System.out.println("4. Salir");
            opcion = sn.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Por favor introduzca el monto a ingresar");
                    ingreso = sn.nextInt();
                    saldo = entrada(saldo,ingreso);
                    break;
                case 2:
                    System.out.println("Por favor introduzca el monto a retirar");
                    retiro = sn.nextInt();
                    saldo = salida(saldo,retiro);
                    break;
                case 3:
                    System.out.println("Su saldo es: "+saldo+" pesos");
                    break;
                case 4:
                    System.out.println("Hasta luego!");
                    break;
                default:
                    System.out.println("La opcion elegida es incorrecta");
            }
            System.out.println("***************************************");
        } while (opcion != 4);

    }
}