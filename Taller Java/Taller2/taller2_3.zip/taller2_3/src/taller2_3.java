import java.util.Scanner;

public class taller2_3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("¿Cual es su nombre?");
        String nombre = sc.next();

        System.out.println("¿Cual es su apellido?");
        String apellido = sc.next();

        System.out.println("¿Cual es su edad?");
        int edad = sc.nextInt();

        sc.close();

        if (edad >= 18) {
            System.out.println(nombre +  " " + apellido +
                    " usted es mayor de edad, por lo tanto puede entrar a la fiesta.");
        } else {
            System.out.println(nombre +  " " + apellido +
                    " usted es menor de edad, por lo tanto, no puede entrar a la fiesta, por favor devuélvase a su casa.");
        }

    }

}
