import java.util.Scanner;

public class taller2_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("¿Cual es su edad?");
        int edad = sc.nextInt();

        sc.close();

        if (edad >= 18) {
            System.out.println("Usted es mayor de edad.");
        }

    }

}
