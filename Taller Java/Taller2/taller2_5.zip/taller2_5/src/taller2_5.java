import java.util.Scanner;

public class taller2_5 {

    public static void main(String[] args) {

        int compra;
        int devolucion;
        int precio;
        String cliente;
        Scanner sn = new Scanner(System.in);

        System.out.println("Nombre del cliente");
        cliente = sn.next();
        System.out.println("Bienvenido "+cliente+", elija una de las siguientes opciones");
        System.out.println("1. Comprar un producto");
        System.out.println("2. Consultar el precio del producto");
        System.out.println("3. Realizar una devoluci�n");
        int opcion = sn.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("�Cual de los siguientes productos desea comprar?");
                System.out.println("1. Protector Solar Uveblock SPF50+ Dry Touch x 40 ML Isispharma");
                System.out.println("    Brinda una alta protecci�n solar y matifica la piel con tendencia grasosa y sensible al sol. Indicado para pieles sensible.");
                System.out.println("2. Crema Despigmentante Bodytone White x 100ML Isispharma ");
                System.out.println("    Ayuda a reducir y prevenir las manchas pigmentarias corporales incluso en las zonas m�s sensibles del cuerpo (axilas, codos, rodillas y entrepierna).");
                System.out.println("3. Suero Intensivo Age Protect x 30ML Uriage");
                System.out.println("    S�rum potenciador act�a simult�neamente sobre los signos de la edad y las agresiones diarias que sufre la piel.");
                System.out.println("4. Azelac RU Suero Despigmentante x 30ML Sesderma");
                System.out.println("    Triple acci�n el cual bloquea y reduce la producci�n de melanina de forma eficaz. Posee activos liposomados los cuales act�an sobre el origen de las manchas en la piel.");
                System.out.println("5. Huile de Ducha Atoderm x 1L Bioderma");
                System.out.println("    Atoderm aceite de ducha hidrata, alivia y protege de las agresiones externas gracias a su f�rmula exclusiva compuesta de biolipidos vegetales, Vitamina PP y la patente Skin Barrier Therapy.");
                compra = sn.nextInt();
                switch (compra) {
                    case 1:
                        System.out.println("Usted ha comprado el producto: Protector Solar Uveblock SPF50+ Dry Touch x 40 ML Isispharma");
                        break;
                    case 2:
                        System.out.println("Usted ha comprado el producto: Crema Despigmentante Bodytone White x 100ML Isispharma");
                        break;
                    case 3:
                        System.out.println("Usted ha comprado el producto: Suero Intensivo Age Protect x 30ML Uriage");
                        break;
                    case 4:
                        System.out.println("Usted ha comprado el producto: Azelac RU Suero Despigmentante x 30ML Sesderma");
                        break;
                    case 5:
                        System.out.println("Usted ha comprado el producto: Huile de Ducha Atoderm x 1L Bioderma");
                        break;
                    default:
                        System.out.println("Elija un producto correcto");
                }
                break;
            case 2:
                System.out.println("�Cual de los siguientes productos desea conocer el precio?");
                System.out.println("1. Protector Solar Uveblock SPF50+ Dry Touch x 40 ML Isispharma");
                System.out.println("    Brinda una alta protecci�n solar y matifica la piel con tendencia grasosa y sensible al sol. Indicado para pieles sensible.");
                System.out.println("2. Crema Despigmentante Bodytone White x 100ML Isispharma ");
                System.out.println("    Ayuda a reducir y prevenir las manchas pigmentarias corporales incluso en las zonas m�s sensibles del cuerpo (axilas, codos, rodillas y entrepierna).");
                System.out.println("3. Suero Intensivo Age Protect x 30ML Uriage");
                System.out.println("    S�rum potenciador act�a simult�neamente sobre los signos de la edad y las agresiones diarias que sufre la piel.");
                System.out.println("4. Azelac RU Suero Despigmentante x 30ML Sesderma");
                System.out.println("    Triple acci�n el cual bloquea y reduce la producci�n de melanina de forma eficaz. Posee activos liposomados los cuales act�an sobre el origen de las manchas en la piel.");
                System.out.println("5. Huile de Ducha Atoderm x 1L Bioderma");
                System.out.println("    Atoderm aceite de ducha hidrata, alivia y protege de las agresiones externas gracias a su f�rmula exclusiva compuesta de biolipidos vegetales, Vitamina PP y la patente Skin Barrier Therapy.");
                precio = sn.nextInt();
                switch (precio) {
                    case 1:
                        System.out.println("El precio es: $97,500");
                        break;
                    case 2:
                        System.out.println("El precio es: $210,000");
                        break;
                    case 3:
                        System.out.println("El precio es: $168,500");
                        break;
                    case 4:
                        System.out.println("El precio es: $187,000");
                        break;
                    case 5:
                        System.out.println("El precio es: $139,000");
                        break;
                    default:
                        System.out.println("Elija un producto correcto");
                }
                break;
            case 3:
                System.out.println("�Cual producto desea realizar la devoluci�n?");
                System.out.println("1. Protector Solar Uveblock SPF50+ Dry Touch x 40 ML Isispharma");
                System.out.println("2. Crema Despigmentante Bodytone White x 100ML Isispharma");
                System.out.println("3. Suero Intensivo Age Protect x 30ML Uriage");
                System.out.println("4. Azelac RU Suero Despigmentante x 30ML Sesderma");
                System.out.println("5. Huile de Ducha Atoderm x 1L Bioderma");
                devolucion = sn.nextInt();
                switch (devolucion) {
                    case 1:
                        System.out.println("Usted ha devuelto: Protector Solar Uveblock SPF50+ Dry Touch x 40 ML Isispharma, con exito");
                        break;
                    case 2:
                        System.out.println("Usted ha devuelto: Crema Despigmentante Bodytone White x 100ML Isispharma, con exito");
                        break;
                    case 3:
                        System.out.println("Usted ha devuelto: Suero Intensivo Age Protect x 30ML Uriage, con exito");
                        break;
                    case 4:
                        System.out.println("Usted ha devuelto: Azelac RU Suero Despigmentante x 30ML Sesderma, con exito");
                        break;
                    case 5:
                        System.out.println("Usted ha devuelto: Huile de Ducha Atoderm x 1L Bioderma, con exito");
                        break;
                    default:
                        System.out.println("Elija un producto correcto");
                }
                break;
            default:
                System.out.println("La opcion elegida es incorrecta");
        }
    }


}
