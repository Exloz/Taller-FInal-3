const camTema1 = () => {
    document.documentElement.setAttribute('data-theme', 'tema1');
}

const camTema2 = () => {
    document.documentElement.setAttribute('data-theme', 'tema2');
}

const camTema3 = () => {
    document.documentElement.setAttribute('data-theme', 'tema3');
}


